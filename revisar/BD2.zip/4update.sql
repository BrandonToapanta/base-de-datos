use test;
update usuarios set cedula=1714355482 where cedula=1714355485

use test;
update usuarios set nombre='Edison', cedula='0400421459' where cedula='0400421459'

use test;
update usuarios set nombre='EDISON' where nombre='Edison'

use test;
update usuarios set telefono='0983506849' where cedula=1714355482 and nombre='Edison'

use test;
update usuarios set nombre='EDISON' where id='8'