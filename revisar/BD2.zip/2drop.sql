/* Borrar toda la base de datos */
drop database test;

/* Borrar la tabla, hay que especificar la base de datos */
use test;
drop table usuarios;
use test;
drop table productos;
use test;
drop table empresa;

use test;
drop table categoria;

